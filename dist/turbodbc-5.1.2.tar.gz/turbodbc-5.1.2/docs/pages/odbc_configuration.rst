.. _odbc_configuration:

ODBC configuration
==================

ODBC configuration can be a real pain, in particular if you are new to ODBC.
So here is a short primer of what ODBC is about.

.. toctree::
    :maxdepth: 1

    odbc/basics
    odbc/concepts
    odbc/driver_manager_config





