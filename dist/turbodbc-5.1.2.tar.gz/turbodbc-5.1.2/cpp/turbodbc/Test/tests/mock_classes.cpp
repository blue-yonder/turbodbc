#include "mock_classes.h"

namespace turbodbc_test {

default_mock_connection::default_mock_connection() = default;
default_mock_connection::~default_mock_connection() = default;

default_mock_statement::default_mock_statement() = default;
default_mock_statement::~default_mock_statement() = default;

}
