"""
Global constants as required by PEP-249:
https://www.python.org/dev/peps/pep-0249/#globals
"""

apilevel = "2.0"
threadsafety = 1
paramstyle = "qmark"
