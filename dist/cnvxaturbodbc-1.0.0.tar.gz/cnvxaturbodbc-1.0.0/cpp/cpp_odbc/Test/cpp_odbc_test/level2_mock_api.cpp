/**
 *  @file level2_mock_api.cpp
 *  @date 13.03.2014
 *  @author mkoenig
 *  @brief 
 *
 *  $LastChangedDate: 2014-11-28 15:26:51 +0100 (Fr, 28 Nov 2014) $
 *  $LastChangedBy: mkoenig $
 *  $LastChangedRevision: 21210 $
 *
 */

#include "cpp_odbc_test/level2_mock_api.h"

namespace cpp_odbc_test {

level2_mock_api::level2_mock_api() = default;
level2_mock_api::~level2_mock_api() = default;

}
